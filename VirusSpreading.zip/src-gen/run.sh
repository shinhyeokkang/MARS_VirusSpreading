dotnet run -sm config.json
Rscript ../analysis/covid19.R
